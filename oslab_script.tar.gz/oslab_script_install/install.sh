#!/bin/bash

# Define the target directories
BIN_DIR="/usr/local/bin"
COMPLETION_DIR="/etc/bash_completion.d"

DIRECTORY_PATH=$(realpath ..)

read -p "Confirm $DIRECTORY_PATH is path to myexpos folder (Y/n): " RES

if [ $RES == 'n' ] || [ $RES == 'N' ]; then
	echo "exiting..."
	exit
fi 

if [ ! -d $DIRECTORY_PATH ]; then
	echo "$DIRECTORY_PATH does not exist."
	echo "exiting..."
	exit
fi

# Copy script2.sh to /usr/local/bin
sudo cp oslab $BIN_DIR
sudo chmod +x $BIN_DIR/oslab

# Copy script1.sh to /etc/bash_completion.d
sudo cp oslab_completions $COMPLETION_DIR
sudo chmod +x $COMPLETION_DIR/oslab_completions


# Modify script1.sh
sudo sed -i "s|DIR_PLACEHOLDER|$DIRECTORY_PATH|g" $BIN_DIR/oslab

echo "Installation complete!"

